## Sample Output

```
Launch: Starlink-XX on 2025-06-15T08:00:00Z at pad 5e9e4502f5090995de566f86.
Weather: clear sky, Temperature: 303.15K.
Status: on schedule
```